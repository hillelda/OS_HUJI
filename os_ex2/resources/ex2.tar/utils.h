//
// Created by gilad on 4/4/2023.
//

#ifndef _UTILS_H_
#define _UTILS_H_

enum ThreadState{ RUNNING, BLOCKED, READY};


#endif //_UTILS_H_
